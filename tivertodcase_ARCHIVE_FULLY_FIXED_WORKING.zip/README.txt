Tivertodcase rebuilt package

Run locally through a static server, or deploy the folder to Netlify.
Do not open file:// directly if browser blocks fetch requests.

Data source:
- CS2 item names/images are loaded from ByMykel/CSGO-API public JSON.
- Prices use deterministic fallback estimates by rarity + wear. For real live prices, configure a paid CSGOSKINS.GG / SteamAnalyst / Pricempire API key and adapt netlify/functions/prices.js to your provider.
