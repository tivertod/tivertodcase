const API='https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/';
const W=['FN','MW','FT','WW','BS']; const WN={FN:'Factory New',MW:'Minimal Wear',FT:'Field-Tested',WW:'Well-Worn',BS:'Battle-Scarred'};
const WM={FN:1.75,MW:1.25,FT:1,WW:.82,BS:.68};
const RAR={"Consumer Grade":"#b0c3d9","Industrial Grade":"#5e98d9","Mil-Spec Grade":"#4b69ff","Restricted":"#8847ff","Classified":"#d32ce6","Covert":"#eb4b4b","Contraband":"#e4ae39","Extraordinary":"#e4ae39","Exotic":"#d32ce6","Remarkable":"#8847ff","High Grade":"#4b69ff","Base Grade":"#b0c3d9","Superior":"#d32ce6","Exceptional":"#8847ff","Distinguished":"#4b69ff","Master":"#eb4b4b"};
let state={balance:245,spent:0,inventory:[],upgradeHistory:[],lang:localStorage.lang||'ru',qty:1,selectedCase:null,pending:[],market:[],cases:[],daily:[],upgradeInv:null,upgradeTarget:null,upgradePending:null,upgradeMultiplier:1.5,manualTarget:false,livePrices:{},priceProvider:'fallback'};
try{Object.assign(state,JSON.parse(localStorage.tivertodState||'{}'));}catch(e){}
const T={ru:{navCases:'Кейсы',navDaily:'Daily',navMarket:'Market',navUpgrade:'Upgrade',navProfile:'Профиль',navDeposit:'Депозит',dailyTitle:'Daily кейсы',dailyProgress:'Прогресс Daily',yourItem:'Ваш предмет',targetItem:'Цель',balanceStake:'Баланс в апгрейд',upgradeBtn:'Апгрейд',inventory:'Инвентарь',depositTitle:'Пополнение',keep:'Оставить',sell:'Продать',caseContains:'Содержимое кейса',open:'Открыть',notEnough:'Недостаточно средств',won:'Выпало',added:'Добавлено в инвентарь',sold:'Продано за',cooldown:'Доступно через'},en:{navCases:'Cases',navDaily:'Daily',navMarket:'Market',navUpgrade:'Upgrade',navProfile:'Profile',navDeposit:'Deposit',dailyTitle:'Daily cases',dailyProgress:'Daily progress',yourItem:'Your item',targetItem:'Target',balanceStake:'Balance stake',upgradeBtn:'Upgrade',inventory:'Inventory',depositTitle:'Deposit',keep:'Keep',sell:'Sell',caseContains:'Case contents',open:'Open',notEnough:'Not enough balance',won:'Drop',added:'Added to inventory',sold:'Sold for',cooldown:'Available in'},ua:{navCases:'Кейси',navDaily:'Daily',navMarket:'Market',navUpgrade:'Upgrade',navProfile:'Профіль',navDeposit:'Депозит',dailyTitle:'Daily кейси',dailyProgress:'Прогрес Daily',yourItem:'Ваш предмет',targetItem:'Ціль',balanceStake:'Баланс в апгрейд',upgradeBtn:'Апгрейд',inventory:'Інвентар',depositTitle:'Поповнення',keep:'Залишити',sell:'Продати',caseContains:'Вміст кейса',open:'Відкрити',notEnough:'Недостатньо коштів',won:'Випало',added:'Додано в інвентар',sold:'Продано за',cooldown:'Доступно через'}};
function tr(k){return (T[state.lang]&&T[state.lang][k])||T.ru[k]||k} function save(){localStorage.tivertodState=JSON.stringify({balance:state.balance,spent:state.spent,inventory:state.inventory,upgradeHistory:state.upgradeHistory});}
function money(v){return '$'+Number(v||0).toFixed(2)} function id(x){return document.getElementById(x)} function img(s){return s?.image||s?.img||'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22280%22 height=%22180%22%3E%3Crect width=%22100%25%22 height=%22100%25%22 rx=%2218%22 fill=%22%23101010%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23ff3030%22 font-size=%2222%22%3ECS2%3C/text%3E%3C/svg%3E'}
function rarityColor(s){return s?.rarityColor||RAR[s?.rarity]||s?.rarity?.color||'#4b69ff'}
function normMarketName(name=''){
  return String(name).toLowerCase().replace(/^★\s*/,'').replace(/\s*\((factory new|minimal wear|field-tested|well-worn|battle-scarred)\)\s*$/i,'').replace(/\s+/g,' ').trim();
}
async function loadLivePrices(){
  state.livePrices={}; state.priceProvider='fallback';
  try{
    const r=await fetch('/.netlify/functions/prices',{cache:'no-store'});
    if(!r.ok) throw new Error('price proxy '+r.status);
    const data=await r.json();
    if(data&&data.prices){state.livePrices=data.prices;state.priceProvider=data.provider||'proxy';console.log('prices loaded',state.priceProvider,Object.keys(state.livePrices).length)}
  }catch(e){console.warn('Live prices unavailable, using fallback prices',e)}
}
function livePrice(item,wear){
  const map=state.livePrices||{};
  const base=normMarketName(item?.market_hash_name||item?.marketName||item?.name||'');
  const w=wear||item?.wear||'';
  return map[base+'::'+w]||map[base]||null;
}
function upd(){id('topBalance').textContent=money(state.balance);id('profileBalance').textContent=money(state.balance);id('balanceStake').max=Math.floor(state.balance); save();}
function setLang(l){state.lang=l;localStorage.lang=l;document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=tr(e.dataset.i18n));document.querySelectorAll('[data-ph]').forEach(e=>e.placeholder=tr(e.dataset.ph)||e.placeholder);renderAll();}
function nav(p){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));id(p).classList.add('active'); if(p==='market')renderMarket(); if(p==='upgrade')renderUpgrade(); if(p==='profile')renderProfile(); if(p==='daily')renderDaily();}
function weaponOf(name){return (name.split('|')[0]||name).replace('★','').trim()} function skinName(name){return (name.split('|')[1]||name).trim()}
function knifeTier(n){
  if(!n.startsWith('★'))return 1;
  if(n.includes('Butterfly Knife'))return 1.95;
  if(n.includes('Karambit'))return 1.75;
  if(n.includes('M9 Bayonet'))return 1.48;
  if(n.includes('Talon Knife'))return 1.38;
  if(n.includes('Skeleton Knife'))return 1.35;
  if(n.includes('Bayonet'))return 1.28;
  if(n.includes('Flip Knife'))return 1.05;
  if(n.includes('Huntsman Knife'))return .92;
  if(n.includes('Bowie Knife'))return .82;
  if(n.includes('Falchion Knife'))return .78;
  if(n.includes('Navaja Knife'))return .55;
  if(n.includes('Shadow Daggers'))return .58;
  if(n.includes('Gut Knife'))return .62;
  if(n.includes('Ursus Knife'))return .95;
  if(n.includes('Nomad Knife'))return .98;
  if(n.includes('Survival Knife'))return .86;
  if(n.includes('Paracord Knife'))return .82;
  if(n.includes('Classic Knife'))return .9;
  return 1;
}
function basePrice(item){let r=item.rarity||'';let n=item.name||'';let p={"Consumer Grade":.25,"Industrial Grade":.8,"Mil-Spec Grade":2.2,"Restricted":7,"Classified":24,"Covert":95,"Contraband":900,"Extraordinary":250,"Exotic":18,"Remarkable":6,"High Grade":1.6,"Base Grade":.5,"Superior":12,"Exceptional":5,"Distinguished":2,"Master":35}[r]||3; let h=0; for(let c of n)h=(h*31+c.charCodeAt(0))%997; p*=.65+(h%100)/70; if(n.includes('Dragon Lore'))p=1200;if(n.includes('Medusa'))p=950;if(n.includes('Howl'))p=1200;if(n.includes('Fire Serpent'))p=850;if(n.includes('Vice'))p=1200;if(n.includes('Pandora'))p=1200;if(n.includes('Doppler'))p=Math.max(p,780);if(n.includes('Gamma Doppler'))p=Math.max(p,950);if(n.includes('Marble Fade'))p=Math.max(p,900);if(n.includes('Fade'))p=Math.max(p,650); if(n.includes('Case Hardened'))p=Math.max(p,240); if(n.includes('Lore'))p=Math.max(p,450); if(n.startsWith('★'))p=Math.max(p,160)*knifeTier(n); return Math.min(1200,Math.max(.03,p));}
function premiumPriceBoost(item,wear){
  let n=item?.name||'';
  if(!n.startsWith('★') && basePrice(item)<500)return 1;
  let q=wear||item?.wear||'FT', m=1;
  if(n.includes('Doppler'))m*=2.15;
  if(n.includes('Gamma Doppler'))m*=2.35;
  if(n.includes('Marble Fade'))m*=2.05;
  if(n.includes('Fade'))m*=1.75;
  if(n.includes('Tiger Tooth'))m*=1.55;
  if(n.includes('Lore'))m*=1.45;
  if(n.includes('Slaughter'))m*=1.38;
  if(n.includes('Case Hardened'))m*=1.32;
  if(n.includes('Crimson Web'))m*=1.25;
  if(q==='FN')m*=1.55; else if(q==='MW')m*=1.22; else if(q==='FT')m*=1; else if(q==='WW')m*=.82; else if(q==='BS')m*=.68;
  return m;
}
function price(item,wear){let lp=livePrice(item,wear); if(lp) return +Number(lp).toFixed(2); let q=wear||item.wear||'FT'; let raw=basePrice(item)*(basePrice(item)>=500||String(item.name||'').startsWith('★')?premiumPriceBoost(item,q):(WM[q]||1)); return +Math.max(.03,raw).toFixed(2)}
function makeWear(item){let wear=W[Math.floor(Math.random()*W.length)];return {...item,wear,price:price(item,wear),uid:Date.now()+Math.random()}}
function tile(s,cls='skinIcon'){return `<div class="${cls}" style="--rar:${rarityColor(s)}"><img loading="lazy" src="${img(s)}" onerror="this.src='${img()}'"></div>`}
async function fetchJson(path){let r=await fetch(API+path); if(!r.ok)throw new Error(path); return r.json();}
function fallbackSkins(){const I='https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/default_generated/';return ['AK-47 | Redline','AK-47 | Asiimov','AK-47 | Vulcan','AK-47 | Fire Serpent','AWP | Asiimov','AWP | Neo-Noir','AWP | Lightning Strike','M4A4 | Asiimov','M4A1-S | Printstream','Desert Eagle | Printstream','Glock-18 | Water Elemental','USP-S | Kill Confirmed'].map((n,i)=>({id:'fb'+i,name:n,weapon:weaponOf(n),type:'Skin',rarity:['Mil-Spec Grade','Restricted','Classified','Covert'][i%4],rarityColor:RAR[['Mil-Spec Grade','Restricted','Classified','Covert'][i%4]],image:I+['weapon_ak47_cu_ak47_cobra_light_png.png','weapon_ak47_cu_ak47_asiimov_light_png.png','weapon_ak47_cu_ak47_vulcan_light_png.png','weapon_ak47_aq_oiled_light_png.png','weapon_awp_cu_awp_asimov_light_png.png','weapon_awp_cu_awp_neonoir_light_png.png','weapon_awp_am_lightning_awp_light_png.png','weapon_m4a1_cu_m4_asimov_light_png.png','weapon_m4a1_silencer_cu_m4a1s_printstream_light_png.png','weapon_deagle_cu_deag_printstream_light_png.png','weapon_glock_am_water_elemental_light_png.png','weapon_usp_silencer_cu_usp_kill_confirmed_light_png.png'][i]}));}
async function initData(){await loadLivePrices();let skins=[];try{skins=(await fetchJson('skins.json')).filter(s=>s.image&&s.name&&s.weapon&&s.rarity).map(s=>({id:s.id,name:s.name,weapon:s.weapon.name,type:'Skin',rarity:s.rarity.name,rarityColor:s.rarity.color,image:s.image}));}catch(e){skins=fallbackSkins();}
 skins=skins.filter(s=>!s.name.includes('Souvenir') && !s.name.includes('Gold Arabesque') && !s.name.includes('Wild Lotus'));
 let market=[...skins];
 try{let [cr,st,gr,mus,ag]=await Promise.all([fetchJson('crates.json'),fetchJson('stickers.json'),fetchJson('graffiti.json'),fetchJson('music_kits.json'),fetchJson('agents.json')]);
 market.push(...cr.filter(x=>x.image).map(x=>({id:x.id,name:x.name,type:x.type||'Case',weapon:'Other',rarity:x.rarity?.name||'Base Grade',rarityColor:x.rarity?.color||RAR['Base Grade'],image:x.image,wear:'',price:Math.max(.03,((x.name.length%40)+1)/3)})));
 market.push(...st.filter(x=>x.image).map(x=>({id:x.id,name:x.name,type:'Sticker',weapon:'Sticker',rarity:x.rarity?.name||'High Grade',rarityColor:x.rarity?.color||RAR['High Grade'],image:x.image,wear:'',price:Math.max(.03,((x.name.length%90)+1)/2)})));
 market.push(...gr.filter(x=>x.image).map(x=>({id:x.id,name:x.name,type:'Graffiti',weapon:'Graffiti',rarity:x.rarity?.name||'Base Grade',rarityColor:x.rarity?.color||RAR['Base Grade'],image:x.image,wear:'',price:Math.max(.03,((x.name.length%15)+1)/8)})));
 market.push(...mus.filter(x=>x.image).map(x=>({id:x.id,name:x.name,type:'Music Kit',weapon:'Music',rarity:x.rarity?.name||'High Grade',rarityColor:x.rarity?.color||RAR['High Grade'],image:x.image,wear:'',price:Math.max(.5,((x.name.length%80)+10)/3)})));
 market.push(...ag.filter(x=>x.image).map(x=>({id:x.id,name:x.name,type:'Agent',weapon:'Agent',rarity:x.rarity?.name||'Superior',rarityColor:x.rarity?.color||RAR['Superior'],image:x.image,wear:'',price:Math.max(1,((x.name.length%120)+10)/2)})));
 }catch(e){}
 state.market=market.map(x=>({...x,base:basePrice(x),price:x.price||price(x,'FT')})); buildCases(skins); renderAll(); }
function buildCases(skins){let by={}; skins.forEach(s=>{if(basePrice(s)<=1200){(by[s.weapon]||(by[s.weapon]=[])).push(s)}}); let order=['Glock-18','USP-S','P2000','P250','Five-SeveN','Tec-9','CZ75-Auto','Dual Berettas','Desert Eagle','R8 Revolver','AK-47','M4A4','M4A1-S','AWP','SSG 08','SG 553','AUG','FAMAS','Galil AR','G3SG1','SCAR-20','MAC-10','MP9','MP7','MP5-SD','UMP-45','P90','PP-Bizon','Nova','XM1014','MAG-7','Sawed-Off','M249','Negev'];
 let cases=[]; order.forEach(w=>{let items=(by[w]||[]).sort((a,b)=>basePrice(a)-basePrice(b)); if(items.length)cases.push({id:'weapon_'+w,name:w+' Case',group:['Glock-18','USP-S','P2000','P250','Five-SeveN','Tec-9','CZ75-Auto','Dual Berettas','Desert Eagle','R8 Revolver'].includes(w)?'Pistols':['AK-47','M4A4','M4A1-S','AWP','SSG 08','SG 553','AUG','FAMAS','Galil AR','G3SG1','SCAR-20'].includes(w)?'Rifles':['Nova','XM1014','MAG-7','Sawed-Off','M249','Negev'].includes(w)?'Heavy':'SMGs',price:Math.max(3.99,Math.min(49.99,avg(items)*.72)),cover:items[Math.floor(items.length*.78)]?.image||items[0].image,items});});
 let knives={}; skins.filter(s=>s.name.startsWith('★')&&s.name.includes('Knife |')).forEach(s=>{let k=s.name.split('|')[0].replace('★','').trim();(knives[k]||(knives[k]=[])).push(s)});
 Object.entries(knives).forEach(([k,items])=>{let pool=items.filter(x=>basePrice(x)<=1200); if(!pool.length)return; let avgKnife=pool.reduce((a,x)=>a+price(x,'FT'),0)/pool.length; let minKnife=Math.min(...pool.map(x=>price(x,'BS'))); let casePrice=Math.min(1899.99,Math.max(minKnife*.62,avgKnife*.58,149.99)); cases.push({id:'knife_'+k,name:k+' Case',group:'Knives',price:+casePrice.toFixed(2),cover:pool[Math.floor(pool.length*.65)]?.image||pool[0].image,items:pool})});
 let gloves=skins.filter(s=>s.name.startsWith('★')&&s.name.includes('Gloves |')&&basePrice(s)<=1200); if(gloves.length){let avgGlove=gloves.reduce((a,x)=>a+price(x,'FT'),0)/gloves.length;let minGlove=Math.min(...gloves.map(x=>price(x,'BS')));let glovePrice=Math.min(1899.99,Math.max(minGlove*.62,avgGlove*.58,179.99));cases.push({id:'gloves',name:'Gloves Case',group:'Gloves',price:+glovePrice.toFixed(2),cover:gloves[Math.floor(gloves.length*.6)].image,items:gloves});}
 state.cases=cases; state.daily=[{lvl:1,need:10,min:.3,max:25,price:0},{lvl:2,need:50,min:2,max:30,price:0},{lvl:3,need:100,min:5,max:55,price:0},{lvl:4,need:250,min:10,max:100,price:0},{lvl:5,need:500,min:15,max:200,price:0}].map(d=>{let pool=skins.filter(s=>basePrice(s)>=d.min&&basePrice(s)<=d.max).slice(0,30); if(d.lvl===5){let vice=skins.find(s=>s.name.includes('Vice')); if(vice)pool.push({...vice,ultra:true})}return {id:'daily_'+d.lvl,name:'Daily LVL '+d.lvl,group:'Daily',cover:pool[Math.floor(pool.length/2)]?.image||state.cases[0]?.cover,items:pool,need:d.need,price:0,daily:true,lvl:d.lvl}});}
function avg(items){return items.reduce((a,x)=>a+price(x,'FT'),0)/Math.max(1,items.length)}
function renderAll(){document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=tr(e.dataset.i18n));upd();renderCases();renderDaily();renderMarketFilters();renderMarket();renderUpgrade();renderProfile();renderLive();}
function renderCases(){let wrap=id('caseGroups'); if(!state.cases.length){wrap.innerHTML='<p>Loading...</p>';return;} let groups={};state.cases.forEach(c=>(groups[c.group]||(groups[c.group]=[])).push(c)); wrap.innerHTML=Object.entries(groups).map(([g,arr])=>`<h2 class="groupTitle">${g}</h2><div class="grid">${arr.map(caseCard).join('')}</div>`).join('');}
function caseCard(c){return `<div class="card caseCard" onclick="openCaseModal('${c.id}')"><div class="cover"><img src="${c.cover}" onerror="this.src='${img()}'"></div><h3>${c.name}</h3><div class="price">${c.price?money(c.price):'FREE'}</div><button class="btn">${tr('open')}</button></div>`}
function renderDaily(){let next=[10,50,100,250,500].find(x=>state.spent<x)||500; id('spentInfo').textContent=`${money(state.spent)} / ${money(next)}`; id('spentBar').style.width=Math.min(100,state.spent/next*100)+'%'; id('dailyGrid').innerHTML=state.daily.map(c=>{let last=+localStorage['daily_'+c.lvl]||0, left=Math.max(0,86400000-(Date.now()-last)), locked=state.spent<c.need; return `<div class="card caseCard ${locked?'locked':''}" onclick="${locked?'':'openCaseModal(\''+c.id+'\')'}"><div class="cover"><img src="${c.cover}" onerror="this.src='${img()}'"></div><h3>${c.name}</h3><p>${locked?'Need '+money(c.need):left?tr('cooldown')+' '+fmt(left):'FREE'}</p></div>`}).join('')}
function fmt(ms){let h=Math.floor(ms/3600000),m=Math.floor(ms%3600000/60000);return h+'h '+m+'m'} setInterval(()=>{if(id('daily').classList.contains('active'))renderDaily()},60000);
function openCaseModal(cid){let c=[...state.cases,...state.daily].find(x=>x.id===cid); state.selectedCase=c;state.qty=1;state.pending=[];id('modalCover').src=c.cover;id('modalTitle').textContent=c.name;id('modalPrice').textContent=c.price?money(c.price):'FREE';document.querySelectorAll('.qty button').forEach((b,i)=>b.classList.toggle('active',i===0));let qtyBox=document.querySelector('.qty'); if(qtyBox) qtyBox.style.display=c.daily?'none':'flex';id('spinArea').innerHTML='';id('dropResult').innerHTML='';id('caseActions').style.display='none';id('modalItems').innerHTML=c.items.map(s=>tile(s)).join('');id('caseModal').style.display='flex';}
function setQty(q){state.qty=q;document.querySelectorAll('.qty button').forEach(b=>b.classList.toggle('active',+b.textContent===q));}
function closeCase(){id('caseModal').style.display='none';}
function weighted(c,exp){let pool=c.items.filter(Boolean);let e=exp||.72; let weights=pool.map(it=>{let p=basePrice(it);let w=1/Math.pow(Math.max(.05,p),e);if(it.ultra)w=.000001;return w});let total=weights.reduce((a,b)=>a+b,0);let r=Math.random()*total;for(let i=0;i<pool.length;i++){r-=weights[i];if(r<=0)return makeWear(pool[i])}return makeWear(pool[0])}
function multiRiskExp(q){q=Number(q)||1; if(q>=10)return 1.18; if(q>=5)return 1.08; if(q>=3)return .98; if(q>=2)return .88; return .72;}
function rollLaneToWinner(lane,track,winIndex){
  requestAnimationFrame(()=>{
    const targetTile=track.children[winIndex];
    if(!targetTile)return;
    const laneCenter=lane.clientWidth/2;
    const targetCenter=targetTile.offsetLeft+targetTile.offsetWidth/2;
    const finalX=Math.max(0,targetCenter-laneCenter);
    const overshoot=36;
    track.style.transition='transform 5.05s cubic-bezier(.08,.75,.12,1)';
    track.style.transform=`translateX(-${finalX+overshoot}px)`;
    setTimeout(()=>{track.style.transition='transform .48s ease-out';track.style.transform=`translateX(-${finalX}px)`;},5050);
  });
}
function openSelectedCase(){let c=state.selectedCase;if(c.daily){state.qty=1;let last=+localStorage['daily_'+c.lvl]||0;if(Date.now()-last<86400000){id('dropResult').textContent=tr('cooldown')+' '+fmt(86400000-(Date.now()-last));return;} if(state.spent<c.need){id('dropResult').textContent='Locked';return;} localStorage['daily_'+c.lvl]=Date.now();}
 let total=(c.price||0)*state.qty;if(state.balance<total){id('dropResult').textContent=tr('notEnough');return}state.balance-=total;state.spent+=total;upd();state.pending=[];id('spinArea').innerHTML='';id('dropResult').innerHTML='';id('caseActions').style.display='none';let wins=[];let exp=multiRiskExp(state.qty);for(let i=0;i<state.qty;i++){let w=weighted(c,exp);w.uid=Date.now()+Math.random()+i;wins.push(w);}
 const winIndex=52,totalRollItems=72;
 wins.forEach((win,idx)=>{let lane=document.createElement('div');lane.className='spinLane';let track=document.createElement('div');track.className='track';let list=[];for(let j=0;j<totalRollItems;j++)list.push(weighted(c,exp));list[winIndex]=win;track.innerHTML=list.map(s=>`<div class="tile" style="--rar:${rarityColor(s)}"><img src="${img(s)}" onerror="this.src='${img()}'"></div>`).join('');lane.appendChild(track);id('spinArea').appendChild(lane);rollLaneToWinner(lane,track,winIndex);});
 setTimeout(()=>{state.pending=wins;state.inventory.unshift(...wins);save();id('spinArea').style.transition='opacity .35s ease';id('spinArea').style.opacity='0';setTimeout(()=>{id('spinArea').innerHTML='';id('spinArea').style.opacity='1';},380);id('dropResult').innerHTML=`<div class="resultGrid">${wins.map((s,i)=>`<div class="resultCard" style="--rar:${rarityColor(s)};animation-delay:${Math.min(i*120,1200)}ms"><div class="skinIcon" style="--rar:${rarityColor(s)}"><img src="${img(s)}" onerror="this.src='${img()}'"></div><div class="resultMeta"><b>${s.wear||''}</b><span>${money(s.price)}</span></div><button class="btn ghost" onclick="sellResultItem('${s.uid}')">${tr('sell')}</button></div>`).join('')}</div>`;id('caseActions').style.display='flex';wins.forEach(s=>addLive(s));renderDaily();renderProfile();},5900)}
function keepPending(silent){state.pending=[];id('caseActions').style.display='none';renderProfile();save();}
function sellResultItem(uid){let idx=state.inventory.findIndex(x=>String(x.uid)===String(uid));if(idx>-1){state.balance+=state.inventory[idx].price;state.inventory.splice(idx,1);upd();renderProfile();}state.pending=state.pending.filter(x=>String(x.uid)!==String(uid));let el=document.querySelector(`[onclick="sellResultItem('${uid}')"]`); if(el){let card=el.closest('.resultCard'); if(card) card.remove();} if(!state.pending.length)id('caseActions').style.display='none';}
function sellPending(){let sum=0;state.pending.forEach(p=>{let i=state.inventory.findIndex(x=>String(x.uid)===String(p.uid));if(i>-1){sum+=state.inventory[i].price;state.inventory.splice(i,1);}});state.pending=[];state.balance+=sum;upd();id('caseActions').style.display='none';id('dropResult').innerHTML='<div class="dropSold">'+tr('sold')+' '+money(sum)+'</div>';renderProfile();}
function addLive(s){let d=document.createElement('div');d.className='liveDrop';d.style.setProperty('--glow',rarityColor(s));d.innerHTML=`<img src="${img(s)}" onerror="this.src='${img()}'"><b>${s.name.split('|').pop()}</b><div class="price">${money(s.price)}</div>`;id('liveTrack').prepend(d)}
function renderLive(){if(id('liveTrack').children.length)return;[...state.cases.slice(0,10)].forEach(c=>addLive(weighted(c)))}
function renderMarketFilters(){let weapons=[...new Set(state.market.filter(x=>x.weapon).map(x=>x.weapon))].sort();id('filterWeapon').innerHTML='<option value="all">All weapons</option>'+weapons.map(w=>`<option>${w}</option>`).join('');let rar=[...new Set(state.market.map(x=>x.rarity).filter(Boolean))].sort();id('filterRarity').innerHTML='<option value="all">All rarities</option>'+rar.map(r=>`<option>${r}</option>`).join('');['marketSearch','filterType','filterWeapon','filterRarity','filterWear','minPrice','maxPrice','sortMarket'].forEach(k=>id(k).oninput=renderMarket)}
function marketItemWithWear(x){if(x.type==='Skin'){let wear=id('filterWear')?.value||'all'; if(wear==='all')wear='FT';return {...x,wear,price:price(x,wear)}} return x}
function renderMarket(){let q=(id('marketSearch')?.value||'').toLowerCase(),ft=id('filterType')?.value||'all',fw=id('filterWeapon')?.value||'all',fr=id('filterRarity')?.value||'all',min=+id('minPrice')?.value||0,max=+id('maxPrice')?.value||999999;let arr=state.market.map(marketItemWithWear).filter(x=>(!q||x.name.toLowerCase().includes(q))&&(ft==='all'||x.type===ft||x.type.includes(ft))&&(fw==='all'||x.weapon===fw)&&(fr==='all'||x.rarity===fr)&&x.price>=min&&x.price<=max);let sort=id('sortMarket')?.value;if(sort==='priceAsc')arr.sort((a,b)=>a.price-b.price);else if(sort==='priceDesc')arr.sort((a,b)=>b.price-a.price);else arr.sort((a,b)=>a.name.localeCompare(b.name));id('marketGrid').innerHTML=arr.slice(0,240).map((s,i)=>`<div class="card skinCard">${tile(s)}<h3>${s.name}</h3><p>${s.wear||''} <span class="price">${money(s.price)}</span></p><button class="btn" onclick="buyMarket('${s.id}',${i})">Buy</button></div>`).join('');id('upgradeMarket').innerHTML=arr.slice(0,80).map(s=>`<div class="card skinCard" onclick="selectTarget('${s.id}')">${tile(s)}<h3>${s.name}</h3><p class="price">${money(s.price)}</p></div>`).join('')}
function buyMarket(mid){let base=state.market.find(x=>x.id===mid);let s=marketItemWithWear(base);if(state.balance<s.price)return alert(tr('notEnough'));state.balance-=s.price;state.spent+=s.price;state.inventory.unshift({...s,uid:Date.now()+Math.random()});upd();renderAll();}
function renderUpgrade(){
  id('balanceStake').max=Math.floor(state.balance);
  id('stakeInfo').textContent=money(+id('balanceStake').value||0);
  id('balanceStake').oninput=()=>{id('stakeInfo').textContent=money(+id('balanceStake').value||0);state.manualTarget=false;autoSelectTarget();calcUpgrade()};
  document.querySelectorAll('.multiBtn').forEach(b=>b.classList.toggle('active',Number(b.dataset.m)===Number(state.upgradeMultiplier)));
  id('upgradeInv').innerHTML=state.inventory.map(s=>`<div class="card skinCard ${state.upgradeInv&&String(state.upgradeInv.uid)===String(s.uid)?'selected':''}" onclick="selectInv('${s.uid}')">${tile(s)}<h3>${s.name}</h3><p>${s.wear||''} <span class="price">${money(s.price)}</span></p></div>`).join('')||'<div class="card">Empty</div>';
  renderMarket();
  autoSelectTarget(false);
  calcUpgrade();
}
function setMultiplier(m){
  state.upgradeMultiplier=Number(m)||1.5;
  state.manualTarget=false;
  document.querySelectorAll('.multiBtn').forEach(b=>b.classList.toggle('active',Number(b.dataset.m)===Number(state.upgradeMultiplier)));
  autoSelectTarget();
  calcUpgrade();
}
function selectInv(uid){
  state.upgradeInv=state.inventory.find(x=>String(x.uid)===String(uid));
  state.manualTarget=false;
  id('chosenInv').classList.remove('empty');
  id('chosenInv').innerHTML=tile(state.upgradeInv);
  autoSelectTarget();
  calcUpgrade();
}
function setTargetVisual(s){
  state.upgradeTarget=s;
  id('chosenTarget').classList.remove('empty');
  id('chosenTarget').innerHTML=tile(s);
}
function selectTarget(mid){
  let s=state.market.find(x=>x.id===mid);
  state.manualTarget=true;
  setTargetVisual(marketItemWithWear(s));
  calcUpgrade();
}
function stakeValue(){return (state.upgradeInv?.price||0)+(+id('balanceStake').value||0)}
function autoSelectTarget(force=true){
  if(state.manualTarget&&!force)return;
  const stake=stakeValue();
  if(!stake)return;
  const desired=stake*(Number(state.upgradeMultiplier)||1.5);
  let arr=state.market.filter(x=>x.type==='Skin').map(marketItemWithWear).filter(x=>x.price>=desired).sort((a,b)=>a.price-b.price);
  if(!arr.length)arr=state.market.map(marketItemWithWear).sort((a,b)=>b.price-a.price);
  if(arr[0])setTargetVisual(arr[0]);
}
function calcUpgrade(){
  let ch=0;if(state.upgradeTarget){ch=Math.min(85,Math.max(1,stakeValue()/state.upgradeTarget.price*88));}
  id('upgradeChance').textContent=ch.toFixed(2)+'%';id('upgradeWheel').style.setProperty('--deg',(ch/100*360)+'deg');
}
function runUpgrade(){
  let target=state.upgradeTarget;if(!target)return;let bal=+id('balanceStake').value||0;if(state.balance<bal)return alert(tr('notEnough'));
  let inv=state.upgradeInv;let chance=Math.min(85,Math.max(1,stakeValue()/target.price*88));let roll=Math.random()*100;
  id('upgradeArrow').style.transition='none';id('upgradeArrow').style.transform='translate(-50%,-100%) rotate(0deg)';
  setTimeout(()=>{id('upgradeArrow').style.transition='transform 3.2s cubic-bezier(.08,.75,.12,1)';id('upgradeArrow').style.transform=`translate(-50%,-100%) rotate(${720+roll/100*360}deg)`},50);
  state.balance-=bal;state.spent+=bal+(inv?.price||0);if(inv){state.inventory=state.inventory.filter(x=>x.uid!==inv.uid)}
  setTimeout(()=>{let win=roll<=chance;state.upgradeHistory.unshift({target:target.name,chance:chance.toFixed(2),result:win?'WIN':'LOSE',price:target.price});
    if(win){state.upgradePending={...target,uid:Date.now()+Math.random()};id('upgradeStatus').innerHTML='WIN '+target.name+' '+money(target.price);id('targetActions').style.display='flex'}else{id('upgradeStatus').innerHTML='LOSE';id('targetActions').style.display='none'}
    state.upgradeInv=null;state.manualTarget=false;id('chosenInv').innerHTML='?';id('chosenInv').classList.add('empty');id('balanceStake').value=0;upd();renderUpgrade();renderProfile();
    setTimeout(()=>{id('upgradeArrow').style.transition='transform .4s ease';id('upgradeArrow').style.transform='translate(-50%,-100%) rotate(0deg)'},500);
  },3400)
}
function claimUpgrade(){if(state.upgradePending){state.inventory.unshift(state.upgradePending);state.upgradePending=null;id('targetActions').style.display='none';renderAll();}}
function sellUpgrade(){if(state.upgradePending){state.balance+=state.upgradePending.price;state.upgradePending=null;id('targetActions').style.display='none';upd();renderAll();}}
function renderProfile(){id('profileItems').style.display='grid';id('profileUpgrades').style.display='none';id('profileItems').innerHTML=[...state.inventory].sort((a,b)=>(b.uid||0)-(a.uid||0)).map(s=>`<div class="card skinCard">${tile(s)}<h3>${s.name}</h3><p>${s.wear||''} <span class="price">${money(s.price)}</span></p><button class="btn" onclick="sellInv('${s.uid}')">Sell</button><button class="btn ghost" onclick="withdraw('${s.uid}')">Withdraw</button></div>`).join('')||'<div class="card">Empty</div>';id('profileUpgrades').innerHTML=state.upgradeHistory.map(h=>`<div class="card"><h3 style="color:${h.result==='WIN'?'#38ff78':'#ff3030'}">${h.result}</h3><p>${h.target}</p><p>${h.chance}% • ${money(h.price)}</p></div>`).join('')||'<div class="card">Empty</div>'}
function profileTab(t){id('profileItems').style.display=t==='items'?'grid':'none';id('profileUpgrades').style.display=t==='upgrades'?'grid':'none'}
function sellInv(uid){let i=state.inventory.findIndex(x=>String(x.uid)===String(uid));if(i>-1){state.balance+=state.inventory[i].price;state.inventory.splice(i,1);upd();renderAll()}}
function sellAllInventory(){let sum=state.inventory.reduce((a,s)=>a+s.price,0);state.balance+=sum;state.inventory=[];upd();renderAll()}
function withdraw(uid){alert('Withdraw request created')}
function deposit(){let a=+id('depAmount').value||0;if(a>0){state.balance+=a;upd();}}
document.addEventListener('input',e=>{if(e.target.closest('.filters'))renderMarket();});document.addEventListener('change',e=>{if(e.target.closest('.filters'))renderMarket();});
initData();
