const WEAR_TO_CODE = {
  'Factory New': 'FN',
  'Minimal Wear': 'MW',
  'Field-Tested': 'FT',
  'Well-Worn': 'WW',
  'Battle-Scarred': 'BS'
};

const cache = { ts: 0, body: null };
const TTL_MS = Number(process.env.PRICE_CACHE_SECONDS || 300) * 1000;

function json(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'access-control-allow-origin': '*',
      'cache-control': `public, max-age=${Math.floor(TTL_MS / 1000)}`
    },
    body: JSON.stringify(payload)
  };
}

function normName(name = '') {
  return String(name)
    .toLowerCase()
    .replace(/^★\s*/, '')
    .replace(/\s*\((factory new|minimal wear|field-tested|well-worn|battle-scarred)\)\s*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function wearCode(name = '') {
  const m = String(name).match(/\((Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)\)$/i);
  if (!m) return null;
  const exact = Object.keys(WEAR_TO_CODE).find(k => k.toLowerCase() === m[1].toLowerCase());
  return exact ? WEAR_TO_CODE[exact] : null;
}

function num(v) {
  if (v === null || v === undefined) return null;
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  const n = Number(String(v).replace(/[^0-9.]/g, ''));
  return Number.isFinite(n) ? n : null;
}

function putPrice(map, marketName, price) {
  const p = num(price);
  if (!marketName || !p || p <= 0) return;
  const base = normName(marketName);
  const wear = wearCode(marketName);
  if (wear) map[`${base}::${wear}`] = Math.round(p * 100) / 100;
  else map[base] = Math.round(p * 100) / 100;
}

async function fromSkinport() {
  const currency = process.env.PRICE_CURRENCY || 'USD';
  const url = `https://api.skinport.com/v1/items?app_id=730&currency=${encodeURIComponent(currency)}`;
  const headers = { 'accept': 'application/json' };
  if (process.env.SKINPORT_API_KEY) headers.authorization = 'Basic ' + Buffer.from(process.env.SKINPORT_API_KEY + ':' + (process.env.SKINPORT_API_SECRET || '')).toString('base64');
  const r = await fetch(url, { headers });
  if (!r.ok) throw new Error(`Skinport ${r.status}`);
  const arr = await r.json();
  const prices = {};
  for (const item of arr || []) {
    const name = item.market_hash_name || item.name;
    const p = item.min_price ?? item.suggested_price ?? item.mean_price ?? item.median_price;
    putPrice(prices, name, p);
  }
  return { provider: 'skinport', prices };
}

async function fromCustomProvider() {
  const endpoint = process.env.CSGOSKINS_ENDPOINT || process.env.PRICE_API_ENDPOINT;
  const key = process.env.CSGOSKINS_API_KEY || process.env.PRICE_API_KEY;
  if (!endpoint || !key) throw new Error('Custom provider not configured');
  const r = await fetch(endpoint, {
    headers: {
      'accept': 'application/json',
      'authorization': `Bearer ${key}`,
      'x-api-key': key
    }
  });
  if (!r.ok) throw new Error(`Custom price provider ${r.status}`);
  const data = await r.json();
  const list = Array.isArray(data) ? data : (data.items || data.data || data.results || []);
  const prices = {};
  for (const item of list) {
    const name = item.market_hash_name || item.marketName || item.name || item.hash_name;
    const p = item.price || item.min_price || item.suggested_price || item.mean_price || item.median_price || item.value;
    putPrice(prices, name, p);
  }
  return { provider: 'custom', prices };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  const now = Date.now();
  if (cache.body && now - cache.ts < TTL_MS) return json(200, cache.body);

  try {
    let result;
    try {
      result = await fromCustomProvider();
    } catch (_) {
      result = await fromSkinport();
    }
    const body = {
      ok: true,
      provider: result.provider,
      updatedAt: new Date().toISOString(),
      currency: process.env.PRICE_CURRENCY || 'USD',
      count: Object.keys(result.prices).length,
      prices: result.prices
    };
    cache.ts = now;
    cache.body = body;
    return json(200, body);
  } catch (error) {
    return json(200, {
      ok: false,
      provider: 'fallback',
      reason: error.message,
      prices: {}
    });
  }
};
